//___FILEHEADER___

#import "___FILEBASENAME___.h"

@interface ___FILEBASENAME___ ()

/// 子view

@end


@implementation ___FILEBASENAMEASIDENTIFIER___

#pragma mark - 初始化视图、懒加载
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self initMainViews];
    }
    return self;
}

- (void)initMainViews {
}

#pragma mark - 数据处理
- (void)setDataSource(<#GMMCustom#> *)dataSource {
    _dataSource = dataSource;
}

#pragma mark - 布局方法
- (void)setFrame:(CGRect)frame {
    super.frame = frame;
}

-(void)layoutSubviews{
    [super layoutSubviews];
}

@end
