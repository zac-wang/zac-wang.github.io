//___FILEHEADER___

#import "___FILEBASENAME___.h"

@interface ___FILEBASENAME___ ()

/// 子view

@end

@implementation ___FILEBASENAMEASIDENTIFIER___

#pragma mark - 初始化视图、懒加载
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        //设置view
        [self initMainViews];
    }
    return self;
}

- (void)initMainViews {
}

#pragma mark - 数据处理
- (void)setDataSource(<# GMMCustom #> *)dataSource {
    _dataSource = dataSource;
}

#pragma mark - 布局方法
- (void)setFrame:(CGRect)frame {
    super.frame = frame;
}

-(void)layoutSubviews{
    [super layoutSubviews];
}

/// 获取cell高度
+ (CGFloat)getHeight {
    return 0.f;
}

@end
