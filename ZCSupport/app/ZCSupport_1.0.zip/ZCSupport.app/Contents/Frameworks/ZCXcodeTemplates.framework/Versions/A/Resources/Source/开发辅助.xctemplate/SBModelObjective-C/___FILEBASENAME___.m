//___FILEHEADER___

#import "___FILEBASENAME___.h"

@implementation ___FILEBASENAMEASIDENTIFIER___

- (instancetype)init {
    if (self = [super init]) {
        // 数组属性 元素为自定义Class类型，须设置元素类型
        //_myArr = [NSArray arrayWithObject:[[GMMCustomModel alloc] init]];
    }
    return self;
}

@end
