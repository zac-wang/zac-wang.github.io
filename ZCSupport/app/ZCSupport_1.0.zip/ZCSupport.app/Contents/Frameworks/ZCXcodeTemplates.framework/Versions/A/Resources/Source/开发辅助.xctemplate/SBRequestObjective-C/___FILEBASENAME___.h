//___FILEHEADER___

___IMPORTHEADER_cocoaTouchSubclass___

NS_ASSUME_NONNULL_BEGIN

@interface ___FILEBASENAMEASIDENTIFIER___ : ___VARIABLE_cocoaTouchSubclass___

#pragma mark - 接口请求参数
@property (nonatomic, strong) NSString *name;


#pragma mark - 接口返回数据
//@property (nonatomic, strong) GMMCustom *resultModel;

@end

NS_ASSUME_NONNULL_END
