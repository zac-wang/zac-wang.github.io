//___FILEHEADER___

___IMPORTHEADER_cocoaTouchSubclass___

NS_ASSUME_NONNULL_BEGIN

@interface ___FILEBASENAMEASIDENTIFIER___ : ___VARIABLE_cocoaTouchSubclass___

/// 数据源
@property(nonatomic, strong) <# GMMCustom #> *dataSource;

@end

NS_ASSUME_NONNULL_END
