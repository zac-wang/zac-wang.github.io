//___FILEHEADER___

#import "___FILEBASENAME___.h"

@interface ___FILEBASENAMEASIDENTIFIER___ ()

@end


@implementation ___FILEBASENAMEASIDENTIFIER___

#pragma mark - ********************************** View 生命周期方法 ***********************************
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupNavBar]; // 初始化 Nav 导航栏
    [self setupView]; // 初始化界面
    [self initVariable]; // 初始化变量
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self requestData]; // 请求数据
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [self.view endEditing:YES];
}

#pragma mark - ********************************** 初始化参数以及Views ***********************************
/// 初始化 Nav 导航栏
- (void)setupNavBar {
}

/// 初始化 View
- (void)setupView {
}

/// 初始化变量
- (void)initVariable {
}

#pragma mark - *************************************** 数据请求 ****************************************
/// 请求数据
- (void)requestData {
}

@end
