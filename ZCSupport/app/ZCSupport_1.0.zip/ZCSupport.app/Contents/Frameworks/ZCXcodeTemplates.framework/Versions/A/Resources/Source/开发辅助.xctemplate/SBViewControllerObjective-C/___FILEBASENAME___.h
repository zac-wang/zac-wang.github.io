//___FILEHEADER___

___IMPORTHEADER_cocoaTouchSubclass___

NS_ASSUME_NONNULL_BEGIN

/// <# 页面功能名称 #>
@interface ___FILEBASENAMEASIDENTIFIER___ : ___VARIABLE_cocoaTouchSubclass___

#pragma mark - 由其他页面跳转本VC，需传入的参数/实例方法


#pragma mark -

@end

NS_ASSUME_NONNULL_END
