//___FILEHEADER___

___IMPORTHEADER_cocoaTouchSubclass___

NS_ASSUME_NONNULL_BEGIN

@interface ___FILEBASENAMEASIDENTIFIER___ : ___VARIABLE_cocoaTouchSubclass___

#pragma mark - 接口返回数据字段


#pragma mark - 自定义字段（处理后数据、用户标记）

@end

NS_ASSUME_NONNULL_END
