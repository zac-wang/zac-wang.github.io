//___FILEHEADER___

#import "___FILEBASENAME___.h"

@implementation ___FILEBASENAMEASIDENTIFIER___

/// 请求成功后返回的参数
- (void)handleReqSuccResult {
    [super handleReqSuccResult];
    
//    GMMCustom *model = [[GMMCustom alloc] init];
//    [model toSelf:self.idHandleredResult];
//    _resultModel = model;
}

///请求失败返回的参数
- (void)handleReqFailResult {
    [super handleReqFailResult];
    
//    NSDictionary *dicResult = self.idHandleredResult;
//    self.failCode = dicResult[@"failCode"];
//    self.failReason = dicResult[@"failReason"];
}

/// 请求参数
- (NSDictionary *)getDicParam {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params gmSetObject:self.name forKey:@"name"];
    return params;
}

/// 请求URL
- (NSString *)getStrRequestURL {
    /// 建议url统一存放位置，本处只放url宏
    return @"%@/haiwaigou/cart/cartQueryV2.jsp";
}

@end
